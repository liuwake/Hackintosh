//
//  Arguments.h
//  CloverUpdate
//
//  Copyright (c) 2013 Slice. All rights reserved.
//

#ifndef CloverUpdate_Arguments_h
#define CloverUpdate_Arguments_h

extern char* arg1;
extern char* arg2;


#endif
