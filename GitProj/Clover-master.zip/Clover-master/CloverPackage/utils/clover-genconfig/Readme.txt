You have to boot with Clover rev.1672+ with some minimum config.plist then type in terminal
clover-genconfig >config.plist

It is useful to remember your settings made in Options menu if you successfully boot into system.

Works with Clover-64 rev1672+.
