//
//  partutil.h
//  partutil
//
//  Created by Yves Blusseau on 28/12/2014.
//  Copyright (c) 2014-2015 JrCs. All rights reserved.
//

#ifndef partutil_partutil_h
#define partutil_partutil_h

// macros
#define STRINGIFY(s) #s
#define STRINGIFY2(s) STRINGIFY(s)
#define PROGNAME_S STRINGIFY2(PROGNAME)

#define VERSION_S  STRINGIFY(0.15)

#endif
