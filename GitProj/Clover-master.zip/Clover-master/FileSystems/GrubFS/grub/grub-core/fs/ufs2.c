/* ufs2.c - Unix File System 2 */
#define MODE_UFS2 1
#include "ufs.c"
