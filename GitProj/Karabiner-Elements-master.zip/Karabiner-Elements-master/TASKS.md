# Tasks

## Until 12.6.0 release

- [ ] Improve macOS Catalina support.
- [ ] Add `event_type` to `to` in order to support `key_down` only event.
