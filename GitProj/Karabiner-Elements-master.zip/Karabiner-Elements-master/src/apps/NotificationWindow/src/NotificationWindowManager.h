@import Cocoa;

@interface NotificationWindowManager : NSObject

@property(nonatomic) NSString* text;

@end
