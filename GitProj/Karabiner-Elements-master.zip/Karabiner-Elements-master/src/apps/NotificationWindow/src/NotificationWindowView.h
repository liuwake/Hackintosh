@import Cocoa;

@interface NotificationWindowView : NSView

@property(weak) IBOutlet NSTextField* text;

@end
