// -*- Mode: objc -*-

@import Cocoa;

@interface SimpleModificationsTargetDeviceMenuManager : NSObject

+ (NSMenu*)createMenu;

@end
