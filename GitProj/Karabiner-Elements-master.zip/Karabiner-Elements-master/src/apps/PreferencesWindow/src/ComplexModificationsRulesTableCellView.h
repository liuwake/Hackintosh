// -*- Mode: objc -*-

@import Cocoa;

@interface ComplexModificationsRulesTableCellView : NSTableCellView

@property(weak) IBOutlet NSButton* removeButton;

@end
