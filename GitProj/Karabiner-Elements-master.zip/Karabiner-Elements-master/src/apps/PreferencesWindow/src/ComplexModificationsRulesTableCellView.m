#import "ComplexModificationsRulesTableCellView.h"

@implementation ComplexModificationsRulesTableCellView
@end
