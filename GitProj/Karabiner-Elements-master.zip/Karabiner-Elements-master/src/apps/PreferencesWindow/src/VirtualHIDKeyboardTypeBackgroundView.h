// -*- Mode: objc -*-

@import Cocoa;

@interface VirtualHIDKeyboardTypeBackgroundView : NSView
@end
