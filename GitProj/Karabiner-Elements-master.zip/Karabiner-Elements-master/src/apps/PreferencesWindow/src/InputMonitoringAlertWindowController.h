// -*- mode: objective-c -*-

@import Cocoa;

@interface InputMonitoringAlertWindowController : NSWindowController

- (void)setup;

@end
