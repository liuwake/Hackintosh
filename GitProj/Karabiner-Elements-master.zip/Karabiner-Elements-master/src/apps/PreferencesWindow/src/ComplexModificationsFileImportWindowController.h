// -*- Mode: objc; Coding: utf-8; indent-tabs-mode: nil; -*-

@import Cocoa;

@interface ComplexModificationsFileImportWindowController : NSWindowController

- (void)setup:(NSString*)url;
- (void)show;

@end
