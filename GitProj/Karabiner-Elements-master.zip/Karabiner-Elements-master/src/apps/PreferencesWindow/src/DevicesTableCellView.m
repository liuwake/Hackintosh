#import "DevicesTableCellView.h"

@implementation DevicesTableCellView
@end
