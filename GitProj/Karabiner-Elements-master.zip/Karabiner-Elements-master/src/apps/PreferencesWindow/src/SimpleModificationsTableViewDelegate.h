// -*- Mode: objc -*-

@import Cocoa;

@interface SimpleModificationsTableViewDelegate : NSObject <NSTableViewDelegate>
@end
