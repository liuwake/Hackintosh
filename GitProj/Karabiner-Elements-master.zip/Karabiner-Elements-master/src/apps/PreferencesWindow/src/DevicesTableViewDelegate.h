// -*- Mode: objc -*-

@import Cocoa;

@interface DevicesTableViewDelegate : NSObject <NSTableViewDelegate>
@end
