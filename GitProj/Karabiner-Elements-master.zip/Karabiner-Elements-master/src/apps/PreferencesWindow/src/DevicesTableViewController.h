// -*- Mode: objc -*-

@import Cocoa;

@interface DevicesTableViewController : NSObject

- (void)setup;
- (void)valueChanged:(id)sender;
- (void)hasCapsLockLedChanged:(id)sender;

@end
