// -*- Mode: objc -*-

@import Cocoa;

@interface FnFunctionKeysTableViewDelegate : NSObject <NSTableViewDelegate>
@end
