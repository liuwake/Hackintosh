// -*- Mode: objc -*-

@import Cocoa;

@interface SimpleModificationsTableViewDataSource : NSObject <NSTableViewDataSource>
@end
