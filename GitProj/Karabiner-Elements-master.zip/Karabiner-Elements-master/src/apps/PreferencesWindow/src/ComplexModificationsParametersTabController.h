// -*- Mode: objc -*-

@import Cocoa;

@interface ComplexModificationsParametersTabController : NSObject

- (void)setup;

@end
