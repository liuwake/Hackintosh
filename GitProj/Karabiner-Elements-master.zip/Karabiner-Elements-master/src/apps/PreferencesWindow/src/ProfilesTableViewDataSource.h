// -*- Mode: objc -*-

@import Cocoa;

@interface ProfilesTableViewDataSource : NSObject <NSTableViewDataSource>
@end
