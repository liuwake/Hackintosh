// -*- Mode: objc -*-

@import Cocoa;

@interface ComplexModificationsRulesTableViewDataSource : NSObject <NSTableViewDataSource>
@end
