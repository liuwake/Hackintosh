// -*- Mode: objc -*-

@import Cocoa;

@interface SimpleModificationsTableCellView : NSTableCellView

@property(weak) IBOutlet NSPopUpButton* popUpButton;
@property(weak) IBOutlet NSButton* removeButton;

@end
