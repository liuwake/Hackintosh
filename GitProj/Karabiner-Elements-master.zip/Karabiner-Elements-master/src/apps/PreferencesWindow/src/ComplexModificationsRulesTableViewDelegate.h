// -*- Mode: objc -*-

@import Cocoa;

@interface ComplexModificationsRulesTableViewDelegate : NSObject <NSTableViewDelegate>
@end
