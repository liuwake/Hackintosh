#import "ProfilesTableCellView.h"

@implementation ProfilesTableCellView
@end
