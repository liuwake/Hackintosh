// -*- Mode: objc -*-

@import Cocoa;

@interface AppDelegate : NSObject <NSApplicationDelegate>

@end
