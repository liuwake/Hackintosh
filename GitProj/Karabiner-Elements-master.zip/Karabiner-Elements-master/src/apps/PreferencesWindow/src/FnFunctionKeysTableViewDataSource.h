// -*- Mode: objc -*-

@import Cocoa;

@interface FnFunctionKeysTableViewDataSource : NSObject <NSTableViewDataSource>
@end
