// -*- Mode: objc -*-

@import Cocoa;

@interface ProfilesTableViewDelegate : NSObject <NSTableViewDelegate>
@end
