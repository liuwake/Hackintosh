#import "SimpleModificationsTableCellView.h"

@implementation SimpleModificationsTableCellView
@end
