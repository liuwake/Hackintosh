// -*- Mode: objc -*-

@import Cocoa;

@interface LogFileTextViewController : NSObject

- (void)monitor;

@end
