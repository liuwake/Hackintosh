// -*- Mode: objc -*-

@import Cocoa;

#define kSystemPreferencesValuesAreUpdated @"kSystemPreferencesValuesAreUpdated"
