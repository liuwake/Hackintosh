// -*- Mode: objc -*-

@import Cocoa;

@interface ComplexModificationsAssetsOutlineViewDataSource : NSObject <NSOutlineViewDataSource>
@end
