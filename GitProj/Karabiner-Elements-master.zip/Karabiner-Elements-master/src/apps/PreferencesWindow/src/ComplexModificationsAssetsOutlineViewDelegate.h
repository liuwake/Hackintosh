// -*- Mode: objc -*-

@import Cocoa;

@interface ComplexModificationsAssetsOutlineViewDelegate : NSObject <NSOutlineViewDelegate>
@end
