// -*- mode: objective-c -*-

@import Cocoa;

@interface KextdAlertWindowController : NSWindowController

- (void)setup;

@end
