// -*- Mode: objc -*-

@import Cocoa;

@interface DevicesTableViewDataSource : NSObject <NSTableViewDataSource>
@end
