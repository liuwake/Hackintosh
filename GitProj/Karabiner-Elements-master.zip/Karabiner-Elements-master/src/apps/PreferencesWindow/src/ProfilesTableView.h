// -*- Mode: objc -*-

@import Cocoa;

@interface ProfilesTableView : NSTableView
@end
