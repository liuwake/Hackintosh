// -*- Mode: objc -*-

@import Cocoa;

@interface TabView : NSTabView
@end
