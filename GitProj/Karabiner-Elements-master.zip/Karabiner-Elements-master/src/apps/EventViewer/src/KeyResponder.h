// -*- Mode: objc -*-

@import Cocoa;

@interface KeyResponder : NSView
@end
