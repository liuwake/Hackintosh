// -*- Mode: objc -*-

#define kKarabinerKitConfigurationIsLoaded @"kKarabinerKitConfigurationIsLoaded"
#define kKarabinerKitDevicesAreUpdated @"kKarabinerKitDevicesAreUpdated"
#define kKarabinerKitSystemPreferencesValuesAreUpdated @"kKarabinerKitSystemPreferencesValuesAreUpdated"
