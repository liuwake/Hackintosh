#pragma once

#include <pqrs/osx/chrono.hpp>
#include <pqrs/osx/chrono/extra/nlohmann_json.hpp>

namespace krbn {
using absolute_time_duration = pqrs::osx::chrono::absolute_time_duration;
} // namespace krbn
