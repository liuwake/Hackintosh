#pragma once

#include <pqrs/osx/iokit_types.hpp>
#include <pqrs/osx/iokit_types/extra/nlohmann_json.hpp>

namespace krbn {
using location_id = pqrs::osx::iokit_hid_location_id;
} // namespace krbn
