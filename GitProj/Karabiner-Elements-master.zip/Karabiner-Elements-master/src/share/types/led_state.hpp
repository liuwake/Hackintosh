#pragma once

#include "stream_utility.hpp"
#include <cstdint>

namespace krbn {
enum class led_state : uint32_t {
  on,
  off,
};
}
