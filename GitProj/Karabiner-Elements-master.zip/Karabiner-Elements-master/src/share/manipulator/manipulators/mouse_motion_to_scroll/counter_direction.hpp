#pragma once

namespace krbn {
namespace manipulator {
namespace manipulators {
namespace mouse_motion_to_scroll {
enum class counter_direction {
  none,
  vertical,
  horizontal,
};
}
} // namespace manipulators
} // namespace manipulator
} // namespace krbn
