#pragma once

int run_tests(int argc, char* argv[]);
