#include "test_runner.hpp"

int main(int argc, char* argv[]) {
  return run_tests(argc, argv);
}
